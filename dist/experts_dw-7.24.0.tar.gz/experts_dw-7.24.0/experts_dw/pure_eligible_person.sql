CREATE OR REPLACE FORCE EDITIONABLE VIEW EXPERT.PURE_ELIGIBLE_PERSON (
  EMPLID
) AS (
  SELECT emplid
  FROM pure_eligible_affiliate
  UNION
  SELECT emplid
  FROM pure_eligible_employee
  UNION
  SELECT emplid
  FROM pure_eligible_poi
  UNION
  SELECT person_id
  FROM pure_eligible_graduate_program
