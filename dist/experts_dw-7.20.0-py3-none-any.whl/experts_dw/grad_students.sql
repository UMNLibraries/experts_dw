WITH period_start AS (
  SELECT
    stix.emplid,
    stix.acad_career,
    stix.institution,
    stix.um_acad_plan_prima,
    MIN(term.term_begin_dt) AS start_date
  FROM ps_dwsa_stix_1223_pr@dweprd.oit stix
  JOIN ps_dwsa_prog_dtl@dweprd.oit prog
    ON  prog.emplid         = stix.emplid
    AND prog.acad_career    = stix.acad_career
    AND prog.institution    = stix.institution
    AND prog.acad_plan      = stix.um_acad_plan_prima
    AND prog.prog_status    = 'AC'
  JOIN cs_ps_term_tbl@dweprd.oit term
    ON  term.institution = prog.institution
    AND term.acad_career = prog.acad_career
    AND term.strm        = prog.admit_term
  WHERE stix.level2 IN ('GRAD','PRFL')
  GROUP BY stix.emplid, stix.acad_career, stix.institution, stix.um_acad_plan_prima
),
program_status AS (
  SELECT 
    stix.emplid, 
    stix.acad_career, 
    stix.institution, 
    stix.um_acad_plan_prima, 
    prog.prog_status, 
    CASE prog.prog_status 
      WHEN 'CM' THEN 1 -- Completed Program
      WHEN 'CN' THEN 2 -- Cancelled
      WHEN 'DC' THEN 3 -- Discontinued
      WHEN 'DE' THEN 4 -- Deceased
      WHEN 'DM' THEN 5 -- Dismissed
      ELSE 9
      -- Other states: 
      -- AC: Active in Program
      -- AD: Admitted
      -- AP: Applicant
      -- LA: Leave of Absence
      -- PM: Prematriculant
      -- SP: Suspended
      -- WT: Waitlisted
    END AS prog_status_rank,
    prog.ps_descr, -- program status description
    prog.effdt
  FROM ps_dwsa_stix_1223_pr@dweprd.oit stix
  JOIN ps_dwsa_prog_dtl@dweprd.oit prog
    ON  prog.emplid            = stix.emplid
    AND prog.acad_career       = stix.acad_career
    AND prog.institution       = stix.institution
    AND prog.acad_plan         = stix.um_acad_plan_prima
    AND prog.curr_record       = 'Y'
  WHERE stix.level2 IN ('GRAD','PRFL')
),
program_status_ranked AS (
  SELECT
    emplid,
    acad_career,
    institution,
    um_acad_plan_prima,
    prog_status,
    prog_status_rank,
    ps_descr,
    effdt,
    ROW_NUMBER() OVER (
      PARTITION BY 
        emplid,
        acad_career,
        institution,
        um_acad_plan_prima
      ORDER BY prog_status_rank, effdt
    ) AS row_number
  FROM program_status
),
period_end AS (
  SELECT
    emplid,
    acad_career,
    institution,
    um_acad_plan_prima,
    prog_status,
    ps_descr,
    CASE
      WHEN prog_status_rank < 9 THEN effdt
      ELSE NULL
    END AS end_date
  FROM program_status_ranked
  WHERE row_number = 1
)
SELECT
  'autoid:' || stix.emplid || '-' || stix.um_acad_plan_prima || '-' || stix.degree || '-' || TO_CHAR(period_start.start_date, 'YYYY-MM-DD') AS student_org_association_id,
  stix.emplid AS person_id,
  period_start.start_date AS period_start_date,
  period_end.end_date AS period_end_date,
  stix.name, -- Use for demographic data?
  stix.um_acad_plan_prima AS org_id,
  stix.deptid, -- Use to verify existence of Pure parent org.
  stix.deptid_descr, -- Use for error reporting in case of missing Pure parent org.
  stix.reg_sta AS status, -- Seems to almost always be "Continuing, regardless of program status. See below.
  period_end.prog_status, -- We had orginally planned to use stix.reg_sta as status, but this...
  period_end.ps_descr, -- ...or this seems to be more helpful.
  stix.degree AS affiliation_id,
  stix.degree_descr AS student_type_description,
  CASE
    WHEN demog.um_dirc_exclude IN (
      '5', -- Suppress All Information - TOTAL SUPPRESSION
      '6', -- Suppress Phone, Address, Email - DIRECTORY SUPPRESSION
      NULL -- Default to NULL if we have no directory suppression value.
    ) THEN NULL 
    ELSE demog.emailid_1
  END AS email_address
FROM ps_dwsa_stix_1223_pr@dweprd.oit stix -- 1223 is the term. We will use multiple such values, to query multiple term tables.
JOIN period_start 
  ON  period_start.emplid             = stix.emplid
  AND period_start.acad_career        = stix.acad_career
  AND period_start.institution        = stix.institution
  AND period_start.um_acad_plan_prima = stix.um_acad_plan_prima
JOIN period_end
  ON  period_end.emplid             = stix.emplid
  AND period_end.acad_career        = stix.acad_career
  AND period_end.institution        = stix.institution
  AND period_end.um_acad_plan_prima = stix.um_acad_plan_prima
LEFT OUTER JOIN ps_dwsa_demo_addr_rt@dweprd.oit demog
  ON demog.emplid = stix.emplid
WHERE stix.level2 IN ('GRAD','PRFL')
  -- The following are all part of our Pure unique id, so ensure they're not null:
  AND stix.emplid IS NOT NULL
  AND stix.um_acad_plan_prima IS NOT NULL
  AND stix.degree IS NOT NULL
  AND period_start.start_date IS NOT NULL
ORDER BY stix.emplid;
