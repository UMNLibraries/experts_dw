CREATE OR REPLACE FORCE EDITIONABLE VIEW EXPERT.PURE_ELIGIBLE_DEMOGRAPHICS (
  EMPLID,
  INTERNET_ID,
  NAME,
  LAST_NAME,
  FIRST_NAME,
  MIDDLE_INITIAL,
  NAME_SUFFIX,
  INSTL_EMAIL_ADDR,
  TENURE_FLAG,
  TENURE_TRACK_FLAG,
  PRIMARY_EMPL_RCDNO
) AS
  SELECT DISTINCT
  da.emplid,
  da.internet_id,
  da.name, -- for testing
  da.last_name,
  da.first_name,
  SUBSTR(da.middle_name, 1, 1) AS middle_initial,
  CASE
    WHEN da.name_suffix LIKE 'Jr%' THEN 'Jr'
    WHEN da.name_suffix LIKE 'Sr%' THEN 'Sr'
    WHEN da.name_suffix LIKE 'III%' THEN 'III'
    WHEN da.name_suffix LIKE 'II%' THEN 'II'
    WHEN da.name_suffix LIKE 'IV%' THEN 'IV'
    WHEN da.name_suffix LIKE 'V%' THEN 'V'
    ELSE ''
  END AS name_suffix,
  CASE
    -- For students who have directory suppression enabled,
    -- set their email addresses to NULL, so they won't be
    -- publicly displayed.
    WHEN sa.um_dirc_exclude = 6 THEN NULL -- 6 = directory suppression
    ELSE da.instl_email_addr
  END AS instl_email_addr,
  da.tenure_flag,
  da.tenure_track_flag,
  da.primary_empl_rcdno
  FROM pure_eligible_person_chng_hst p
  JOIN ps_dwhr_demo_addr_vw@dweprd.oit da
    ON p.emplid = da.emplid
  LEFT JOIN ps_dwsa_demo_addr_rt@dweprd.oit sa
    ON p.emplid = sa.emplid
UNION
  SELECT
    sa.emplid,
    ue.internet_id,
    sa.name, -- for testing
    sa.last_name,
    sa.first_name,
    SUBSTR(sa.middle_name, 1, 1) AS middle_initial,
    '' AS name_suffix,
    CASE
      WHEN sa.um_dirc_exclude IN (
        '5', -- Suppress All Information - TOTAL SUPPRESSION
        '6', -- Suppress Phone, Address, Email - DIRECTORY SUPPRESSION
        NULL -- Default to NULL if we have no directory suppression value.
      ) THEN NULL
      ELSE ue.email_addr
    END AS inst_email_addr,
    'N' AS tenure_flag,
    'N' AS tenure_track_flag,
    NULL AS primary_empl_rcdno
  FROM pure_eligible_person_chng_hst p
  JOIN ps_dwsa_demo_addr_rt@dweprd.oit sa
    ON sa.emplid = p.emplid
  JOIN ps_dw_university_email@dweprd.oit ue
    ON ue.emplid = sa.emplid
  LEFT JOIN ps_dwhr_demo_addr_vw@dweprd.oit da
    ON da.emplid = sa.emplid
  WHERE da.emplid IS NULL
