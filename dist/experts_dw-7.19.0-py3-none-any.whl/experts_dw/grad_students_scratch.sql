-- In the comments below, pssoa = pure_sync_student_org_association
SELECT
  emplid, -- person_id
  name, -- Use for demographic data?
  um_acad_plan_prima, -- pssoa.org_id
  degree, -- pssoa.affiliation_id
  degree_descr, -- pssoa.student_type_description
  reg_sta, -- pssoa.status
  deptid -- Use to verify existence of Pure parent org.
FROM ps_dwsa_stix_1223_pr@dweprd.oit
WHERE level2 in ('GRAD','PRFL')
AND emplid IN (
  SELECT emplid
  FROM ps_dwsa_stix_1223_pr@dweprd.oit
  GROUP BY emplid
  HAVING COUNT(emplid) > 1
); -- 0 rows

  ON stix.emplid = email.emplid
WHERE stix.level2 IN ('GRAD','PRFL')
ORDER BY stix.emplid;

-- In the comments below, pssoa = pure_sync_student_org_association
WITH period_start AS (
  SELECT
    stix.emplid,
    stix.acad_career,
    stix.institution,
    stix.um_acad_plan_prima,
    MIN(term.term_begin_dt) AS start_date
  FROM ps_dwsa_stix_1223_pr@dweprd.oit stix
  --LEFT OUTER JOIN ps_dwsa_prog_dtl@dweprd.oit prog
  JOIN ps_dwsa_prog_dtl@dweprd.oit prog
    ON  prog.emplid         = stix.emplid
    AND prog.acad_career    = stix.acad_career
    AND prog.institution    = stix.institution
    AND prog.acad_plan      = stix.um_acad_plan_prima
    AND prog.prog_status    = 'AC'
  --LEFT OUTER JOIN cs_ps_term_tbl@dweprd.oit term
  JOIN cs_ps_term_tbl@dweprd.oit term
    ON  term.institution = prog.institution
    AND term.acad_career = prog.acad_career
    AND term.strm        = prog.admit_term
  --WHERE stix.acad_career != 'UGRD'
  WHERE stix.level2 IN ('GRAD','PRFL')
  GROUP BY stix.emplid, stix.acad_career, stix.institution, stix.um_acad_plan_prima
),
program_status AS (
  SELECT 
    stix.emplid, 
    stix.acad_career, 
    stix.institution, 
    stix.um_acad_plan_prima, 
    prog.prog_status, 
    CASE prog.prog_status 
      WHEN 'CM' THEN 1 
      WHEN 'AC' THEN 2 
      WHEN 'LA' THEN 3 
      ELSE 9 
    END AS ps_rank,
    prog.effdt
  FROM ps_dwsa_stix_1223_pr@dweprd.oit stix
  --LEFT OUTER JOIN ps_dwsa_prog_dtl@dweprd.oit prog
  LEFT OUTER JOIN ps_dwsa_prog_dtl@dweprd.oit prog
    ON prog.emplid             = stix.emplid
    AND prog.acad_career       = stix.acad_career
    AND prog.institution       = stix.institution
    AND prog.acad_plan         = stix.um_acad_plan_prima
    AND prog.curr_record       = 'Y'
  --WHERE stix.acad_career != 'UGRD'
  WHERE stix.level2 IN ('GRAD','PRFL')
),
program_status_ranked AS (
  SELECT
    emplid,
    acad_career,
    institution,
    um_acad_plan_prima,
    prog_status,
    ps_rank,
    effdt,
    ROW_NUMBER() OVER (
      PARTITION BY 
        emplid,
        acad_career,
        institution,
        um_acad_plan_prima
      ORDER BY ps_rank, effdt
    ) AS row_number
  FROM program_status
),
period_end AS (
  SELECT 
    emplid,
    acad_career,
    institution,
    um_acad_plan_prima,
    CASE
      WHEN prog_status = 'CM' THEN effdt
      WHEN prog_status IN ('AC','LA') THEN NULL
      ELSE
        CASE 
          WHEN effdt IS NULL THEN SYSDATE ELSE effdt
        END
    END AS end_date
  FROM program_status_ranked
  WHERE row_number = 1
)
SELECT
  'autoid:' || stix.emplid || '-' || stix.um_acad_plan_prima || '-' || stix.degree || '-' || TO_CHAR(ps.start_date, 'YYYY-MM-DD') AS student_org_association_id,
  stix.emplid AS person_id,
  period_start.start_date AS period_start_date,
  period_end.end_date AS period_end_date,
  stix.name, -- Use for demographic data?
  stix.um_acad_plan_prima AS org_id,
  stix.deptid, -- Use to verify existence of Pure parent org.
  stix.deptid_descr, -- Use for error reporting in case of missing Pure parent org.
  stix.reg_sta AS status,
  stix.degree AS affiliation_id,
  stix.degree_descr AS student_type_description,
  --email.internet_id AS email_address -- What about directory suppression?
    WHEN demog.um_dirc_exclude IN (
      '5', -- Suppress All Information - TOTAL SUPPRESSION
      '6', -- Suppress Phone, Address, Email - DIRECTORY SUPPRESSION
      NULL -- Default to NULL if we have no directory suppression value.
    ) THEN NULL 
    ELSE demog.emailid_1
  END AS email_address
FROM ps_dwsa_stix_1223_pr@dweprd.oit stix
--JOIN ps_dw_university_email@dweprd.oit email 
--  ON stix.emplid = email.emplid
JOIN period_start
  ON  period_start.emplid             = stix.emplid
  AND period_start.acad_career        = stix.acad_career
  AND period_start.institution        = stix.institution
  AND period_start.um_acad_plan_prima = stix.um_acad_plan_prima
JOIN period_end
  ON  period_end.emplid             = stix.emplid
  AND period_end.acad_career        = stix.acad_career
  AND period_end.institution        = stix.institution
  AND period_end.um_acad_plan_prima = stix.um_acad_plan_prima
LEFT OUTER JOIN ps_dwsa_demo_addr_rt@dweprd.oit demog
  ON demog.emplid = stix.emplid
WHERE stix.level2 IN ('GRAD','PRFL')
ORDER BY stix.emplid;

-- In the comments below, pssoa = pure_sync_student_org_association
SELECT
  stix.emplid, -- person_id
  stix.name, -- Use for demographic data?
  stix.term,
  stix.term_descr,
  stix.institution,
  stix.institution_descr,
  stix.alb_descr,
  stix.level1,
  stix.level2,
  stix.degr_status,
  stix.academic_load,
  stix.al_descr,
  stix.acad_prog_primary,
  stix.acad_prog_sdesc,
  stix.acad_prog_ldesc,
  stix.um_acad_plan_prima, -- pssoa.org_id
  stix.acad_plan_sdesc,
  stix.acad_plan_ldesc,
  stix.acad_plan_type,
  stix.apt_descr,
  stix.degree, -- pssoa.affiliation_id
  stix.degree_descr, -- pssoa.student_type_description
  stix.degree_seek_Flag,
  stix.acad_plan_owner,
  stix.acad_sub_plan_SDes,
  stix.acad_sub_plan_ldes,
  stix.reg_sta, -- pssoa.status
  stix.deptid, -- Use to verify existence of Pure parent org.
  stix.deptid_descr,
  stix.college_admin_unit,
  stix.college_admin_unit_descr,
  email.internet_id -- What about directory suppression?
FROM ps_dwsa_stix_1223_pr@dweprd.oit stix
INNER JOIN ps_dw_university_email@dweprd.oit email 
  ON stix.emplid = email.emplid
WHERE stix.level2 IN ('GRAD','PRFL')
ORDER BY stix.emplid;

SELECT
  stix.emplid,
  stix.acad_career,
  stix.institution,
  stix.um_acad_plan_prima,
  MIN(term.term_begin_dt) AS period_start_date
FROM ps_dwsa_stix_1223_pr@dweprd.oit stix
--LEFT OUTER JOIN ps_dwsa_prog_dtl@dweprd.oit prog
JOIN ps_dwsa_prog_dtl@dweprd.oit prog
  ON  prog.emplid         = stix.emplid
  AND prog.acad_career    = stix.acad_career
  AND prog.institution    = stix.institution
  AND prog.acad_plan      = stix.um_acad_plan_prima
  AND prog.prog_status    = 'AC'
--LEFT OUTER JOIN cs_ps_term_tbl@dweprd.oit term
JOIN cs_ps_term_tbl@dweprd.oit term
  ON  term.institution = prog.institution
  AND term.acad_career = prog.acad_career
  AND term.strm        = prog.admit_term
--WHERE stix.acad_career != 'UGRD'
WHERE stix.level2 IN ('GRAD','PRFL')
GROUP BY stix.emplid, stix.acad_career, stix.institution, stix.um_acad_plan_prima;

WITH program_status AS (
  SELECT 
    stix.emplid, 
    stix.acad_career, 
    stix.institution, 
    stix.um_acad_plan_prima, 
    prog.prog_status, 
    CASE prog.prog_status 
      WHEN 'CM' THEN 1 
      WHEN 'AC' THEN 2 
      WHEN 'LA' THEN 3 
      ELSE 9 
    END AS ps_rank,
    prog.effdt
  FROM ps_dwsa_stix_1223_pr@dweprd.oit stix
  --LEFT OUTER JOIN ps_dwsa_prog_dtl@dweprd.oit prog
  LEFT OUTER JOIN ps_dwsa_prog_dtl@dweprd.oit prog
    ON prog.emplid             = stix.emplid
    AND prog.acad_career       = stix.acad_career
    AND prog.institution       = stix.institution
    AND prog.acad_plan         = stix.um_acad_plan_prima
    AND prog.curr_record       = 'Y'
  --WHERE stix.acad_career != 'UGRD'
  WHERE stix.level2 IN ('GRAD','PRFL')
),
program_status_ranked AS (
  SELECT
    emplid,
    acad_career,
    institution,
    um_acad_plan_prima,
    prog_status,
    ps_rank,
    effdt,
    ROW_NUMBER() OVER (
      PARTITION BY 
        emplid,
        acad_career,
        institution,
        um_acad_plan_prima
      ORDER BY ps_rank, effdt
    ) AS rownbr
  FROM program_status
)
SELECT 
  emplid,
  acad_career,
  institution,
  um_acad_plan_prima,
  CASE
    WHEN prog_status = 'CM' THEN effdt
    WHEN prog_status IN ('AC','LA') THEN NULL
    ELSE
      CASE 
        WHEN effdt IS NULL THEN SYSDATE ELSE effdt
      END
  END AS period_end_date
FROM program_status_ranked
WHERE rownbr = 1;


select a.um_acad_plan_prima, a.institution, b.um_acad_plan_prima, b.institution
from ps_dwsa_stix_1223_pr@dweprd.oit a
join ps_dwsa_stix_1223_pr@dweprd.oit b
on a.um_acad_plan_prima = b.um_acad_plan_prima
where a.institution <> b.institution
and a.level2 in ('GRAD','PRFL') AND b.level2 in ('GRAD','PRFL');
